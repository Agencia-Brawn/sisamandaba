<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Formulario1 extends Model
{
    //
}
