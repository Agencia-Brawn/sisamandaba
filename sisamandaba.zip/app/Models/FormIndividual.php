<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FormIndividual extends Model
{
    //
}
