<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="row row-login" >
        <div class="col-md-4 col-lg-6 col-sm-6 col-img-login">
            <img class="img-fluid" src="img/img_login_fundo.webp" alt="">       
        </div>
        
        <!-- div para afastar -->

        <div class="col-md-6 col-lg-6 col-sm-12 col-12 col-form-login">
            <div class="card" >
                <!-- <div class="card-header"><?php echo e(__('Login')); ?></div> -->
                <img  class="img-fluid logo-login" src="img/logo_verde.png" alt="">


                <div class="card-body">

                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="form-group row">
                            <label for="email" class="col-md-3 col-sm-12 col-form-label text-md-right"><?php echo e(__('E-Mail:')); ?></label>

                            <div class="col-md-8">
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-3 col-form-label text-md-right"><?php echo e(__('Senha:')); ?></label>

                            <div class="col-md-8">
                                <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password">

                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                            </div>
                        </div>

                        <!-- LEMBRAR SENHA -->
                        <!-- <div class="form-group row">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Lembrar Senha')); ?>

                                    </label>
                                </div>
                            </div>
                        </div> -->

                        <div class="form-group row mb-0">
                            <div class="col-md-8 offset-md-3">
                                <button type="submit" class="btn btn-primary">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                <span class="espaco"><br></span>

                                <?php if(Route::has('password.request')): ?>
                                    <a style="padding: 0px;" class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Esqueceu a senha ?')); ?>

                                    </a>
                                <?php endif; ?>
                                

                            </div>
                        </div>

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="row section-apoio">
        <h1>
            APOIO
        </h1>

        <div class="col-lg-12 col-md-12 col-sm-12 col-12 col-apoio" >
            <img class="apoio-login img-fluid" src="img/apoio.webp" alt="Logos da UFPA, PPG-SAS e CNPQ">
        </div>

    <!-- 
        <div class="col-lg-2" style="margin: auto; padding-left: 73px;">
            <img style="max-width: 80px;" class="img-fluid" src="img/ufpa.png" alt="">
        </div>
                    
        <div class="col-lg-2" style="margin: auto;  ">
            <img style="max-width: 150px;" class="img-fluid" src="img/cnpq.png" alt="">
        </div>

        <div class="col-lg-2" style="margin: auto;  ">
            <img style="max-width: 150px;" class="img-fluid" src="img/ppg-sas.jpeg" alt="">
        </div> 
    -->

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Documents\GitHub\sisamandaba\resources\views/auth/login.blade.php ENDPATH**/ ?>